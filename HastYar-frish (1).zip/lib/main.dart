import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; 

void main() {
  runApp(const HastyarFreshApp());
} 

class HastyarFreshApp extends StatelessWidget {
  const HastyarFreshApp({super.key}); 

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HastYar Fresh',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: const HomeScreen(),
    );
  }
} 

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key}); 

  // لیستی بەرهەمە تەواوەکانی دوکانەکەت بە کوردی
  final List<Map<String, String>> products = const [
    {'name': 'ران', 'price': '٣٥٠٠ دینار'},
    {'name': 'باڵ', 'price': '٣٠٠٠ دینار'},
    {'name': 'قاچ', 'price': '٢٠٠٠ دینار'},
    {'name': 'سنگ', 'price': '٤٥٠٠ دینار'},
    {'name': 'مریشکی خۆماڵی', 'price': '٥٥٠٠ دینار'},
    {'name': 'دڵ', 'price': '٢٥٠٠ دینار'},
    {'name': 'سۆتەمەنە', 'price': '١٥٠٠ دینار'},
  ]; 

  // فرمانی کردنەوەی واتسئاپ
  void _orderViaWhatsApp(String productName) async {
    // ژمارەی واتسئاپی خۆت لێرە جێگیر کراوە (بە کۆدی عێراق 964)
    String phoneNumber = "9647774244606 "; 
    String message = "سڵاو، دەمەوێت داواکاری تۆمار بکەم بۆ بەرهەمی: $productName";
    
    var url = Uri.parse("https://wa.me/$phoneNumber?text=${Uri.encodeComponent(message)}");
    
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      print("واتسئاپ نەکرایەوە");
    }
  } 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HastYar Fresh - مریشکی فرێش', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.orange[800],
        centerTitle: true,
      ),
      body: Directionality(
        textDirection: TextDirection.rtl, // بۆ ڕێکخستنی زمان و دوگمەکان بە کوردی
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              return Card(
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(15),
                  title: Text(
                    products[index]['name']!.toString(),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    products[index]['price']!.toString(),
                    style: const TextStyle(fontSize: 16, color: Colors.green, fontWeight: FontWeight.bold),
                  ),
                  trailing: ElevatedButton.icon(
                    onPressed: () => _orderViaWhatsApp(products[index]['name']!),
                    icon: const Icon(Icons.phone_android, color: Colors.white),
                    label: const Text('داواکردن لە واتسئاپ', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green[600],
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}